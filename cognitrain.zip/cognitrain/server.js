import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import helmet from 'helmet';
import path from 'path';
import { fileURLToPath } from 'url';
import { Pool } from 'pg';
import bcrypt from 'bcrypt';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const pool = new Pool(); // reads from .env

const app = express();
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    name: 'cogni.sid',
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: false // set true behind HTTPS
    }
  })
);

const pub = path.join(__dirname, 'public');
app.use('/static', express.static(pub)); // CSS/JS
function requireAuth(req, res, next) {                 // keep for API routes
  if (!req.session.user) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

function requireAuthPage(req, res, next) {             // use for HTML pages
  if (!req.session.user) return res.redirect('/login');
  next();
}

function redirectIfAuthed(req, res, next) {            // skip login/register if already logged in
  if (req.session.user) return res.redirect('/home');
  next();
}



function weekBucketFrom(startDate, now = new Date()) {
  // Bucket weeks from the child's registration date.
  const start = new Date(startDate);
  const msPerWeek = 7 * 24 * 60 * 60 * 1000;
  const weeks = Math.floor((now - start) / msPerWeek);
  const weekStart = new Date(start.getTime() + weeks * msPerWeek);
  // return YYYY-MM-DD
  return weekStart.toISOString().slice(0, 10);
}

app.get('/',          (req, res) => res.redirect('/login'));
app.get('/login',     redirectIfAuthed, (req, res) => res.sendFile(path.join(pub, 'login.html')));
app.get('/register',  redirectIfAuthed, (req, res) => res.sendFile(path.join(pub, 'register.html')));
app.get('/home',      requireAuthPage,  (req, res) => res.sendFile(path.join(pub, 'home.html')));
app.get('/training',  requireAuthPage,  (req, res) => res.sendFile(path.join(pub, 'training.html')));
app.get('/dashboard', requireAuthPage,  (req, res) => res.sendFile(path.join(pub, 'dashboard.html')));

// ---------- auth APIs ----------
app.post('/api/register', async (req, res) => {
  try {
    const { child_name, parent_name, parent_phone, parent_email, child_gender, password } = req.body;
    if (!child_name || !password) return res.status(400).json({ error: 'Child name and password required.' });

    // Enforce "username must be child's name"
    const client = await pool.connect();
    try {
      // create in register
      await client.query('BEGIN');
      const reg = await client.query(
        `INSERT INTO register(child_name, parent_name, parent_phone, parent_email, child_gender)
         VALUES ($1,$2,$3,$4,$5)
         ON CONFLICT (child_name) DO NOTHING
         RETURNING child_name, registered_at`,
        [child_name, parent_name, parent_phone, parent_email, child_gender]
      );

      if (reg.rowCount === 0) {
        await client.query('ROLLBACK');
        return res.status(409).json({ error: 'Child already registered.' });
      }

      const hash = await bcrypt.hash(password, 12);
      await client.query(
        `INSERT INTO login(username, password_hash)
         VALUES ($1,$2)`,
        [child_name, hash]
      );

      await client.query('COMMIT');
      return res.json({ ok: true });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Registration failed.' });
  }
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const q = await pool.query(
      `SELECT l.username, l.password_hash, r.registered_at
       FROM login l JOIN register r ON r.child_name = l.username
       WHERE l.username = $1`, [username]
    );
    if (q.rowCount === 0) return res.status(401).json({ error: 'Invalid credentials' });

    const ok = await bcrypt.compare(password, q.rows[0].password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    req.session.user = { username, registered_at: q.rows[0].registered_at };
    req.session.save(err => {                           // <<< important
      if (err) return res.status(500).json({ error: 'Session save failed' });
      res.json({ ok: true });
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Login error' });
  }
});


app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});


// ---------- data APIs ----------
app.get('/api/me', requireAuth, async (req, res) => {
  const { username } = req.session.user;
  const q = await pool.query(
    `SELECT child_name, parent_name, parent_phone, parent_email, child_gender, registered_at
     FROM register WHERE child_name = $1`,
    [username]
  );
  if (q.rowCount === 0) return res.status(404).json({ error: 'Not found' });
  res.json(q.rows[0]);
});

app.get('/api/progress/levels', requireAuth, async (req, res) => {
  const { username } = req.session.user;
  const q = await pool.query(
    `SELECT game_id, MAX(level_unlocked) AS level
     FROM progress WHERE username = $1
     GROUP BY game_id`,
    [username]
  );
  // default level = 1 for games not played yet
  const levels = { 1: 1, 2: 1, 3: 1 };
  q.rows.forEach(r => { levels[r.game_id] = parseInt(r.level, 10) || 1; });
  res.json(levels);
});

// record a play result (correct/total) and update level achieved for week bucket
app.post('/api/progress/record', requireAuth, async (req, res) => {
  const { username, registered_at } = req.session.user;
  const { game_id, correct, total, level_unlocked } = req.body;

  if (![1,2,3].includes(Number(game_id))) return res.status(400).json({ error: 'Invalid game' });

  // bucket week start from the child's actual registration date
  const week_start = weekBucketFrom(registered_at);

  try {
    await pool.query(
      `INSERT INTO progress(username, game_id, week_start, correct_attempts, total_attempts, level_unlocked)
       VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (username, game_id, week_start)
       DO UPDATE SET
         correct_attempts = progress.correct_attempts + EXCLUDED.correct_attempts,
         total_attempts   = progress.total_attempts   + EXCLUDED.total_attempts,
         level_unlocked   = GREATEST(progress.level_unlocked, EXCLUDED.level_unlocked)`,
      [username, game_id, week_start, correct|0, total|0, level_unlocked|1]
    );
    res.json({ ok: true, week_start });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Could not save progress' });
  }
});

app.get('/api/progress/weekly', requireAuth, async (req, res) => {
  const { username } = req.session.user;
  const q = await pool.query(
    `SELECT week_start, correct, total
     FROM weekly_overall WHERE username = $1 ORDER BY week_start`,
    [username]
  );
  res.json(q.rows);
});

// FORM: Register -> redirect to /login
app.post('/auth/register', async (req, res) => {
  try {
    const { child_name, parent_name, parent_phone, parent_email, child_gender, password } = req.body;
    if (!child_name || !password) return res.redirect('/register?err=missing');

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const reg = await client.query(
        `INSERT INTO register(child_name, parent_name, parent_phone, parent_email, child_gender)
         VALUES ($1,$2,$3,$4,$5)
         ON CONFLICT (child_name) DO NOTHING
         RETURNING child_name`,
        [child_name, parent_name, parent_phone, parent_email, child_gender]
      );
      if (reg.rowCount === 0) { await client.query('ROLLBACK'); return res.redirect('/register?err=exists'); }
      const hash = await bcrypt.hash(password, 12);
      await client.query(`INSERT INTO login(username, password_hash) VALUES ($1,$2)`, [child_name, hash]);
      await client.query('COMMIT');
      return res.redirect('/login?ok=1');
    } catch (e) {
      await client.query('ROLLBACK'); throw e;
    } finally {
      client.release();
    }
  } catch (err) {
    console.error(err);
    return res.redirect('/register?err=server');
  }
});

// FORM: Login -> set session, redirect to /home
app.post('/auth/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const q = await pool.query(
      `SELECT l.username, l.password_hash, r.registered_at
       FROM login l JOIN register r ON r.child_name = l.username
       WHERE l.username = $1`, [username]
    );
    if (q.rowCount === 0) return res.redirect('/login?err=1');

    const ok = await bcrypt.compare(password, q.rows[0].password_hash);
    if (!ok) return res.redirect('/login?err=1');

    req.session.user = { username, registered_at: q.rows[0].registered_at };
    req.session.save(() => res.redirect('/home'));     // <<< redirect after save
  } catch (e) {
    console.error(e);
    res.redirect('/login?err=server');
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`CogniTrain running on http://localhost:${port}`));
