// Load in training.html with:
// <script type="module" src="/static/js/training.js"></script>
import { api, ensureAuth, setActive, logout } from '/static/js/auth.js';

window.doLogout = logout;

(async function init() {
  await ensureAuth();
  setActive('nav-training');

  // Profile modal
  const btn = document.getElementById('profileBtn');
  const modal = document.getElementById('profileModal');
  const area = document.getElementById('profileArea');
  btn.addEventListener('click', async () => {
    const p = await api('/api/me');
    area.innerHTML = `
      <p><b>Child:</b> ${p.child_name}</p>
      <p><b>Gender:</b> ${p.child_gender}</p>
      <p><b>Parent:</b> ${p.parent_name}</p>
      <p><b>Mobile:</b> ${p.parent_phone}</p>
      <p><b>Email:</b> ${p.parent_email}</p>
    `;
    modal.classList.add('show');
  });

  // ----- Levels -----
  const maxLevels = 7; // "five or more" — change as you like
  const unlocked = await api('/api/progress/levels'); // {1: n, 2: n, 3: n}

  const makeLevelButtons = (containerId, gameId, playFn) => {
    const c = document.getElementById(containerId);
    c.innerHTML = '';
    for (let lvl = 1; lvl <= maxLevels; lvl++) {
      const b = document.createElement('button');
      b.className = 'button';
      b.textContent = `Level ${lvl}`;
      if (lvl > (unlocked[gameId] || 1)) {
        b.disabled = true;
        b.classList.add('secondary');
      }
      b.addEventListener('click', () => playFn(lvl));
      c.appendChild(b);
    }
  };

  // ---------- Game 1: Memory Match ----------
  const mmArea = document.getElementById('mm-area');
  function playMemoryMatch(level) {
    const pairs = Math.min(2 + level * 2, 18);
    const symbols = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.slice(0, pairs).split('');
    const deck = symbols.concat(symbols).sort(() => Math.random() - 0.5);

    mmArea.innerHTML = '';
    const grid = document.createElement('div');
    grid.style.display = 'grid';
    const side = Math.ceil(Math.sqrt(deck.length));
    grid.style.gridTemplateColumns = `repeat(${side}, 1fr)`;
    grid.style.gap = '8px';
    mmArea.appendChild(grid);

    let flipped = [], found = new Set(), turns = 0;

    deck.forEach((val, idx) => {
      const cell = document.createElement('button');
      cell.className = 'button secondary';
      cell.style.height = '48px';
      cell.dataset.v = val;
      cell.textContent = '🂠';
      cell.onclick = () => {
        if (found.has(idx) || flipped.includes(idx)) return;
        cell.textContent = val;
        flipped.push(idx);
        if (flipped.length === 2) {
          turns++;
          const [a, b] = flipped;
          const ca = grid.children[a], cb = grid.children[b];
          if (ca.dataset.v === cb.dataset.v) {
            found.add(a); found.add(b);
            ca.style.background = '#bbf7d0';
            cb.style.background = '#bbf7d0';
          } else {
            setTimeout(() => { ca.textContent = '🂠'; cb.textContent = '🂠'; }, 500);
          }
          flipped = [];
        }
        if (found.size === deck.length) {
          const correct = deck.length / 2;
          const total = turns;
          api('/api/progress/record', {
            method: 'POST',
            body: JSON.stringify({ game_id: 1, correct, total, level_unlocked: level + 1 })
          }).then(() => {
            alert(`Great job! Level ${level} complete.`);
            location.reload();
          });
        }
      };
      grid.appendChild(cell);
    });
  }

  // ---------- Game 2: Sequence Recall ----------
  const srArea = document.getElementById('sr-area');
  function playSequenceRecall(level) {
    srArea.innerHTML = '';
    const size = 3 + Math.min(level, 3); // up to 6x6
    const tiles = size * size;
    const seqLen = Math.min(3 + level, 10);

    const board = document.createElement('div');
    board.style.display = 'grid';
    board.style.gridTemplateColumns = `repeat(${size}, 32px)`;
    board.style.gap = '6px';
    srArea.appendChild(board);

    const buttons = Array.from({ length: tiles }, () => {
      const b = document.createElement('button');
      b.className = 'button secondary';
      b.textContent = ' ';
      b.style.width = '32px';
      b.style.height = '32px';
      b.disabled = true;
      board.appendChild(b);
      return b;
    });

    const seq = Array.from({ length: seqLen }, () => Math.floor(Math.random() * tiles));
    let i = 0;
    const highlight = () => {
      if (i > 0) buttons[seq[i - 1]].style.background = '';
      if (i === seq.length) {
        buttons.forEach((b, idx) => { b.disabled = false; b.onclick = () => choose(idx); });
        return;
      }
      buttons[seq[i]].style.background = '#fde68a';
      i++; setTimeout(highlight, 600);
    };
    highlight();

    let pos = 0, correct = 0, total = seqLen;
    function choose(idx) {
      if (idx === seq[pos]) {
        buttons[idx].style.background = '#bbf7d0'; correct++; pos++;
        if (pos === seqLen) finish();
      } else {
        buttons[idx].style.background = '#fecaca'; finish();
      }
    }
    function finish() {
      buttons.forEach(b => b.disabled = true);
      api('/api/progress/record', {
        method: 'POST',
        body: JSON.stringify({
          game_id: 2,
          correct,
          total,
          level_unlocked: correct === total ? level + 1 : level
        })
      }).then(() => {
        alert(`You scored ${correct}/${total}.`);
        location.reload();
      });
    }
  }

  // ---------- Game 3: Find the Difference ----------
  const fdArea = document.getElementById('fd-area');
  function playFindDifference(level) {
    fdArea.innerHTML = '';
    const size = 5 + Math.min(level, 3);
    const diffs = Math.min(2 + level, Math.floor(size));

    const palette = ['#e5e7eb', '#d1fae5', '#fee2e2', '#e0e7ff', '#fef3c7'];
    const makeGrid = () => Array.from({ length: size * size }, () => palette[Math.floor(Math.random() * palette.length)]);
    const base = makeGrid();
    const mod = base.slice();

    const diffIdxs = new Set();
    while (diffIdxs.size < diffs) {
      const i = Math.floor(Math.random() * mod.length);
      mod[i] = '#fca5a5';
      diffIdxs.add(i);
    }

    const makeBoard = (arr, clickable) => {
      const board = document.createElement('div');
      board.style.display = 'grid';
      board.style.gridTemplateColumns = `repeat(${size}, 24px)`;
      board.style.gap = '4px';
      arr.forEach((col, idx) => {
        const cell = document.createElement('div');
        cell.style.width = '24px'; cell.style.height = '24px'; cell.style.borderRadius = '4px';
        cell.style.background = col;
        if (clickable) {
          cell.style.cursor = 'pointer';
          cell.onclick = () => handleClick(idx, cell);
        }
        board.appendChild(cell);
      });
      return board;
    };

    let found = 0, clicked = new Set();
    const row = document.createElement('div');
    row.style.display = 'flex'; row.style.gap = '16px';
    row.appendChild(makeBoard(base, false));
    row.appendChild(makeBoard(mod, true));
    fdArea.appendChild(row);

    function handleClick(idx, el) {
      if (clicked.has(idx)) return;
      clicked.add(idx);
      if (diffIdxs.has(idx)) { found++; el.style.outline = '3px solid #22c55e'; }
      else { el.style.outline = '3px solid #ef4444'; }

      if (clicked.size >= diffs) {
        const correct = found, total = diffs;
        api('/api/progress/record', {
          method: 'POST',
          body: JSON.stringify({
            game_id: 3, correct, total,
            level_unlocked: found === diffs ? level + 1 : level
          })
        }).then(() => {
          alert(`You found ${found} of ${diffs} differences.`);
          location.reload();
        });
      }
    }
  }

  // Build level button panels
  makeLevelButtons('levels-mm', 1, playMemoryMatch);
  makeLevelButtons('levels-sr', 2, playSequenceRecall);
  makeLevelButtons('levels-fd', 3, playFindDifference);
})();
