import { api, ensureAuth, setActive, logout } from '/static/js/auth.js';

window.doLogout = logout;

(async function init() {
  await ensureAuth();
  setActive('nav-home');

  const modal = document.getElementById('profileModal');
  const area  = document.getElementById('profileArea');
  const openBtn  = document.getElementById('profileBtn');
  const closeBtn = document.getElementById('profileClose');

  // Open
  openBtn.addEventListener('click', async () => {
    const p = await api('/api/me');
    area.innerHTML = `
      <p><b>Child:</b> ${p.child_name}</p>
      <p><b>Gender:</b> ${p.child_gender}</p>
      <p><b>Parent:</b> ${p.parent_name}</p>
      <p><b>Mobile:</b> ${p.parent_phone}</p>
      <p><b>Email:</b> ${p.parent_email}</p>
      <p class="small">Registered: ${new Date(p.registered_at).toLocaleString()}</p>
      <p class="small"><i>Profile is read-only.</i></p>
    `;
    modal.classList.add('show');
  });

  // Close by button
  closeBtn.addEventListener('click', () => {
    modal.classList.remove('show');
  });

  // Close by clicking the backdrop (outside the panel)
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('show');
  });

  // Close by pressing Esc
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') modal.classList.remove('show');
  });
})();
