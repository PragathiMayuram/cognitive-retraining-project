// public/js/dashboard.js
import { api, ensureAuth, setActive, logout } from '/static/js/auth.js';

window.doLogout = logout;

(async function init() {
  await ensureAuth();
  setActive('nav-dashboard');

  // Profile modal
  const btn = document.getElementById('profileBtn');
  const modal = document.getElementById('profileModal');
  const area = document.getElementById('profileArea');
  btn.addEventListener('click', async () => {
    const p = await api('/api/me');
    area.innerHTML = `
      <p><b>Child:</b> ${p.child_name}</p>
      <p><b>Gender:</b> ${p.child_gender}</p>
      <p><b>Parent:</b> ${p.parent_name}</p>
      <p><b>Mobile:</b> ${p.parent_phone}</p>
      <p><b>Email:</b> ${p.parent_email}</p>
    `;
    modal.classList.add('show');
  });

  // Fetch weekly totals
  const container = document.getElementById('charts');
  let weeks = await api('/api/progress/weekly');

  // Helper: create one pie card
  function makePieCard(week_start, correct, total) {
    const incorrect = Math.max(0, (total || 0) - (correct || 0));
    const card = document.createElement('div'); card.className = 'card';
    const h = document.createElement('h4');
    h.textContent = `Week of ${new Date(week_start).toLocaleDateString()}`;
    const canvas = document.createElement('canvas');
    card.appendChild(h); card.appendChild(canvas);
    container.appendChild(card);

    // global Chart (from chart.umd.min.js)
    new Chart(canvas.getContext('2d'), {
      type: 'pie',
      data: {
        labels: ['Correct', 'Incorrect'],
        datasets: [{ data: [correct || 0, incorrect] }]
      }
    });
  }

  // If no data yet, show a demo loader
  if (!weeks || weeks.length === 0) {
    const emptyCard = document.createElement('div');
    emptyCard.className = 'card';
    emptyCard.innerHTML = `
      <h3>No activity yet</h3>
      <p class="small">Play a few levels in Training to populate charts, or load some demo data here to test the dashboard.</p>
      <button class="button" id="demoBtn">🎯 Load Demo Data</button>
    `;
    container.appendChild(emptyCard);

    document.getElementById('demoBtn').onclick = async () => {
      // Insert a few synthetic records across 3 games for the current week
      await api('/api/progress/record', { method:'POST', body: JSON.stringify({ game_id: 1, correct: 6, total: 10, level_unlocked: 2 }) });
      await api('/api/progress/record', { method:'POST', body: JSON.stringify({ game_id: 2, correct: 4, total: 8,  level_unlocked: 2 }) });
      await api('/api/progress/record', { method:'POST', body: JSON.stringify({ game_id: 3, correct: 7, total: 9,  level_unlocked: 2 }) });
      location.reload();
    };
    return;
  }

  // Render a pie for each week
  weeks.forEach(w => makePieCard(w.week_start, Number(w.correct), Number(w.total)));
})();
