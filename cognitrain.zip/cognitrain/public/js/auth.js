export async function api(path, options = {}) {
    const res = await fetch(path, {
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      ...options
    });
    if (res.status === 401) {
      location.href = '/login';
      return;
    }
    return res.json();
  }
  
  export async function ensureAuth() {
    const me = await api('/api/me');
    return me; // object or redirect already happened
  }
  
  export function setActive(linkId){
    document.querySelectorAll('.nav a').forEach(a=>a.classList.remove('active'));
    const el = document.getElementById(linkId);
    if (el) el.classList.add('active');
  }
  
  export async function logout(){
    await api('/api/logout', { method: 'POST', body: JSON.stringify({}) });
    location.href = '/login';
  }
  